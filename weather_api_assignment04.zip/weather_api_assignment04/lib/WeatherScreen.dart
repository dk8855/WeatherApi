import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class WeatherScreen extends StatefulWidget {
  @override
  _WeatherScreenState createState() => _WeatherScreenState();
}

class _WeatherScreenState extends State<WeatherScreen> {
  final TextEditingController _cityController = TextEditingController();
  Map<String, dynamic>? weatherData;
  bool isLoading = false;

  // Function to fetch weather data from OpenWeatherMap API
  Future<void> fetchWeather(String city) async {
    setState(() {
      isLoading = true;
    });

    // Use the provided API key
    final apiKey = 'bf959b62eb8b87f07457ab10f13b30b6';
    final url = 'https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey&units=metric';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        setState(() {
          weatherData = json.decode(response.body);
          isLoading = false;
        });
      } else {
        setState(() {
          weatherData = null;
          isLoading = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Failed to load weather data. Please check the city name.'),
        ));
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('An error occurred: $e'),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Weather App')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _cityController,
              decoration: InputDecoration(
                labelText: 'Enter city name',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                fetchWeather(_cityController.text.trim());
              },
              child: Text('Get Weather'),
            ),
            SizedBox(height: 20),
            isLoading
                ? CircularProgressIndicator()
                : weatherData != null
                ? WeatherInfoDisplay(weatherData: weatherData!)
                : Text('Enter a city and press Get Weather to see results'),
          ],
        ),
      ),
    );
  }
}

class WeatherInfoDisplay extends StatelessWidget {
  final Map<String, dynamic> weatherData;

  WeatherInfoDisplay({required this.weatherData});

  @override
  Widget build(BuildContext context) {
    // Extract weather information from the API response
    final temperature = weatherData['main']['temp'];
    final description = weatherData['weather'][0]['description'];
    final humidity = weatherData['main']['humidity'];
    final windSpeed = weatherData['wind']['speed'];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Temperature: $temperature °C', style: TextStyle(fontSize: 24)),
        Text('Condition: $description', style: TextStyle(fontSize: 20)),
        Text('Humidity: $humidity%', style: TextStyle(fontSize: 20)),
        Text('Wind Speed: $windSpeed m/s', style: TextStyle(fontSize: 20)),
      ],
    );
  }
}
