package com.example.weather_api_assignment04;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
